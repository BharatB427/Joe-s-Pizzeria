package com.example.bharat.joespizzeria.utility;

/**
 * Created by bharat on 1/21/18.
 */

public class FilePaths {

    public FilePaths() {
    }

    public String FIREBASE_IMAGE_STORAGE = "images/users";
}
