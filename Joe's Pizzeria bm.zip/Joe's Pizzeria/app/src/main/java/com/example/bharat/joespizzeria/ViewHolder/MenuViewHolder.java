package com.example.bharat.joespizzeria.ViewHolder;

import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by bharat on 1/25/18.
 */

public class MenuViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
    public MenuViewHolder(View itemView) {
        super(itemView);
    }

    @Override
    public void onClick(View v) {

    }
}
