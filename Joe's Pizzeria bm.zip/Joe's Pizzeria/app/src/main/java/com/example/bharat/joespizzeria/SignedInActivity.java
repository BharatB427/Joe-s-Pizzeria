package com.example.bharat.joespizzeria;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/**
 * Created by bharat on 1/7/18.
 */

public class SignedInActivity extends AppCompatActivity {
    private static final String TAG = "SignedInActivity";

    FirebaseDatabase database;
    DatabaseReference category;

    RecyclerView recycler_menu;
    RecyclerView.LayoutManager layoutManager;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signedin_activity);


        setupToolBar();
        init();
    }

    private void init(){
        database = FirebaseDatabase.getInstance();
        category = database.getReference("category");



    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.top_menu, menu);
        return true;
    }

    private void setupToolBar() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.profileToolbar);
        toolbar.setTitle("Menu");
        setSupportActionBar(toolbar);
        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Log.d(TAG, "onMenuItemClick: clicked menu item" + item);

                switch (item.getItemId()) {
                    case R.id.signout:
                        Log.d(TAG, "onMenuItemClick: User clicked on signed out");
                        Toast.makeText(SignedInActivity.this, "Signed out", Toast.LENGTH_SHORT).show();
                        FirebaseAuth.getInstance().signOut();
                        redirectLoginScreen();
                        break;


                    case R.id.account_settings:
                        accountSettings();
                        Log.d(TAG, "onMenuItemClick: clicked on account settings");

                }



                return false;
            }
        });
    }


    private void redirectLoginScreen() {
        Log.d(TAG, "redirectLoginScreen: redirecting to login screen.");

        Intent intent = new Intent(SignedInActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }

    private void accountSettings(){
        Log.d(TAG, "accountSettings: redirecting to account settings screen");

        Intent intent = new Intent(SignedInActivity.this,SettingsActivity.class);
        startActivity(intent);
        
    }
}