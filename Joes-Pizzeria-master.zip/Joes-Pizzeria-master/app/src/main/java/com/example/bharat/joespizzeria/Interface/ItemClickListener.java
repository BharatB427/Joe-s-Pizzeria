package com.example.bharat.joespizzeria.Interface;

import android.view.View;

/**
 * Created by bharat on 1/25/18.
 */

public interface ItemClickListener {
    void onClick(View view,int position, boolean isLongClick);
}
